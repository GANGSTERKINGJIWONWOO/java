package mjc.ac.kr.magazine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagazineApplicationTests {

	@Test
	void contextLoads() {
	}

}

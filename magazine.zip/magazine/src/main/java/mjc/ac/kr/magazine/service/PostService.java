package mjc.ac.kr.magazine.service;

import mjc.ac.kr.magazine.entity.Post;
import mjc.ac.kr.magazine.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PostService {

    private final PostRepository postRepository;

    @Autowired
    public PostService(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    // 글 저장
    public Post savePost(Post post) {
        return postRepository.save(post);
    }

    // ID로 글 찾기
    public Post getPostById(Long id) {
        return postRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 글이 존재하지 않습니다. ID: " + id));
    }

    // 모든 글 가져오기
    public List<Post> getAllPosts() {
        return postRepository.findAll();
    }

    // 글 수정
    public Post updatePost(Long id, Post updatedPost) {
        Post existingPost = getPostById(id);
        existingPost.setTitle(updatedPost.getTitle());
        existingPost.setContent(updatedPost.getContent());
        existingPost.setImageUrl(updatedPost.getImageUrl());
        return postRepository.save(existingPost);
    }

    // 글 삭제
    @Transactional
    public void deletePost(Long id) {
        postRepository.deleteById(id);
    }
}
package mjc.ac.kr.magazine.repository;

import mjc.ac.kr.magazine.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {
    // 사용자 이름으로 사용자 검색
    Optional<UserEntity> findByUsername(String username);

    // 사용자 이름 존재 여부 확인
    boolean existsByUsername(String username);
}

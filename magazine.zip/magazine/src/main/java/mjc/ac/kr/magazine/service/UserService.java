package mjc.ac.kr.magazine.service;

import mjc.ac.kr.magazine.entity.UserEntity;
import mjc.ac.kr.magazine.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // 사용자 저장
    public void saveUser(UserEntity userEntity) {
        System.out.println("Saving user to DB: " + userEntity.getUsername()); // 로그 추가
        userRepository.save(userEntity);
    }

    // ID로 사용자 검색
    public UserEntity findUserById(Long id) {
        Optional<UserEntity> userOptional = userRepository.findById(id);
        return userOptional.orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + id));
    }

    // 사용자 이름으로 검색
    public UserEntity findUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("User not found with username: " + username));
    }
}

package mjc.ac.kr.magazine.repository;

import mjc.ac.kr.magazine.entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    // 필요한 경우, 커스텀 쿼리를 여기에 추가하세요.
    // 예: 특정 사용자 작성 글만 조회하는 메서드
    // List<Post> findByUser_Id(Long userId);
}

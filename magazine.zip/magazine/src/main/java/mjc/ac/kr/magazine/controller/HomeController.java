package mjc.ac.kr.magazine.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "home"; // 홈 페이지 템플릿 반환
    }

    @GetMapping("/home")
    public String homePage() {
        return "home"; // "/home" 경로로도 홈 페이지 반환
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login"; // "/login" 경로로 로그인 페이지 반환
    }
}

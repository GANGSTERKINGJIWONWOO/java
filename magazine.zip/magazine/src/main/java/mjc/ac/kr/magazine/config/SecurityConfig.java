package mjc.ac.kr.magazine.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        // 비밀번호 암호화를 사용하지 않음 (테스트 용도)
        return NoOpPasswordEncoder.getInstance();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/posts/**").authenticated() // 글쓰기, 글 목록 등 인증된 사용자만 접근
                        .anyRequest().permitAll() // 나머지 요청은 모든 사용자에게 허용
                )
                .formLogin(login -> login
                        .loginPage("/login") // 로그인 페이지 설정
                        .defaultSuccessUrl("/", true) // 로그인 성공 후 홈 페이지로 리다이렉트
                        .permitAll() // 로그인 페이지는 모든 사용자에게 허용
                )
                .logout(logout -> logout
                        .logoutSuccessUrl("/") // 로그아웃 후 홈 페이지로 리다이렉트
                        .permitAll() // 로그아웃은 모든 사용자에게 허용
                );
        return http.build();
    }
}

package mjc.ac.kr.magazine.config;

public class PasswordEncoderComponent {
}

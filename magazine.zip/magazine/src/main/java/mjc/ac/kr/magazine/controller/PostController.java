package mjc.ac.kr.magazine.controller;

import mjc.ac.kr.magazine.entity.Post;
import mjc.ac.kr.magazine.entity.UserEntity;
import mjc.ac.kr.magazine.service.PostService;
import mjc.ac.kr.magazine.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Controller
@RequestMapping("/posts")
public class PostController {

    private final PostService postService;
    private final UserService userService;

    @Autowired
    public PostController(PostService postService, UserService userService) {
        this.postService = postService;
        this.userService = userService;
    }

    // 글 목록 보기
    @GetMapping("/postlist")
    public String listPosts(Model model) {
        model.addAttribute("posts", postService.getAllPosts());
        return "post_list";
    }

    // 글쓰기 폼
    @GetMapping("/post")
    public String showPostForm(Model model) {
        if (!isAuthenticated()) {
            return "redirect:/login";
        }
        model.addAttribute("post", new Post());
        return "post_form";
    }

    // 글 저장
    @PostMapping("/post")
    public String savePost(@ModelAttribute Post post, @RequestParam("image") MultipartFile image) {
        UserEntity user = getAuthenticatedUser();
        if (user == null) {
            return "redirect:/login";
        }
        post.setUser(user);

        if (!image.isEmpty()) {
            try {
                String imageUrl = saveImage(image);
                post.setImageUrl(imageUrl);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        postService.savePost(post);

        return "redirect:/posts/postlist";
    }

    // 글 수정 페이지
    @GetMapping("/{id}/edit")
    public String editPost(@PathVariable("id") Long postId, Model model) {
        Post post = postService.getPostById(postId);
        if (post == null) {
            return "redirect:/posts/postlist";
        }
        model.addAttribute("post", post);
        return "edit_post_form";
    }

    // 글 수정 처리
    @PostMapping("/{id}/edit")
    public String updatePost(@PathVariable("id") Long postId, @ModelAttribute Post post, @RequestParam("image") MultipartFile image) {

        // 이미지 처리
        if (!image.isEmpty()) {
            try {
                String imageUrl = saveImage(image);
                post.setImageUrl(imageUrl); // 새 이미지 URL로 업데이트
            } catch (IOException e) {
                // 이미지 처리 중 오류 발생 시 예외 처리
                e.printStackTrace();
                // 오류 메시지를 모델에 추가하여 사용자에게 알릴 수 있습니다.
                // model.addAttribute("error", "이미지 업로드 중 오류가 발생했습니다.");
                // return "edit_post_form"; // 또는 적절한 오류 페이지로 리다이렉트
            }
        }

        postService.updatePost(postId, post);

        return "redirect:/posts/postlist";
    }

    // 글 삭제
    @GetMapping("/{id}/delete")
    public String deletePost(@PathVariable("id") Long postId) {
        Post post = postService.getPostById(postId);
        if (post == null) {
            return "redirect:/posts/postlist";
        }

        UserEntity currentUser = getAuthenticatedUser();
        if (currentUser == null || !currentUser.getUserId().equals(post.getUser() != null ? post.getUser().getUserId() : null)) {
            return "redirect:/posts/postlist";
        }

        postService.deletePost(postId);
        return "redirect:/posts/postlist";
    }

    // 로그인된 사용자 정보 가져오기
    private UserEntity getAuthenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        if (username == null || username.isEmpty()) {
            return null;
        }

        UserEntity user = userService.findUserByUsername(username);
        if (user == null) {
            throw new IllegalStateException("로그인된 사용자를 찾을 수 없습니다: " + username);
        }
        return user;
    }

    // 로그인 상태 체크
    private boolean isAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated();
    }

    // 이미지 파일 저장
    private String saveImage(MultipartFile image) throws IOException {
        String extension = image.getOriginalFilename().substring(image.getOriginalFilename().lastIndexOf("."));
        String directory = "src/main/resources/static/images/";
        String fileName = UUID.randomUUID().toString() + extension;
        Path path = Paths.get(directory + fileName);
        Files.write(path, image.getBytes());
        return "/images/" + fileName;
    }
}
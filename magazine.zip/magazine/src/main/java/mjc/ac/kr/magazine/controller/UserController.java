package mjc.ac.kr.magazine.controller;

import mjc.ac.kr.magazine.entity.UserEntity;
import mjc.ac.kr.magazine.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new UserEntity());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") UserEntity userEntity, Model model) {
        System.out.println("Received User: " + userEntity.getUsername()); // 로그 추가
        userEntity.setRole("USER"); // 기본 권한 설정
        userService.saveUser(userEntity);
        return "redirect:/login";
    }
}
